<?php
	$dbhost = "66.147.242.186";
	$dbuser = "urcscon3_bangkok";
	$dbpass = "coffee1N";
	$dbname = "urcscon3_bangkok";

    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    
    ?>